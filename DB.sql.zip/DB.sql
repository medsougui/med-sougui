-- phpMyAdmin SQL Dump
-- version 2.11.0
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 16, 2023 at 01:44 PM
-- Server version: 4.1.22
-- PHP Version: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `stock`
--

-- --------------------------------------------------------

--
-- Table structure for table `tab`
--

CREATE TABLE IF NOT EXISTS `tab` (
  `num` int(2) NOT NULL auto_increment,
  `mode` varchar(20) NOT NULL default '',
  `client` varchar(50) default NULL,
  PRIMARY KEY  (`num`),
  KEY `client` (`client`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `tab`
--

INSERT INTO `tab` (`num`, `mode`, `client`) VALUES
(1, 'f', NULL),
(2, 'r', 'med@email.com'),
(3, 'r', 'med@email.com'),
(4, 'r', 'med@email.com'),
(5, 'f', NULL),
(6, 'f', NULL),
(7, 'f', NULL),
(8, 'r', 'bac@gmail.c'),
(9, 'f', NULL),
(10, 'f', NULL),
(11, 'f', NULL),
(12, 'r', 'bac@gmail.c');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tab`
--
ALTER TABLE `tab`
  ADD CONSTRAINT `tab_ibfk_1` FOREIGN KEY (`client`) REFERENCES `utilisateur` (`email`) ON DELETE SET NULL ON UPDATE CASCADE;
